#抓取PTT電影版
import urllib.request as req
url="https://www.ptt.cc/bbs/movie/index.html"
#建立一個Request物件，附加Request Headers的資訊 
request=req.Request(url,headers={
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
})
#發送請求並取得回應 
with req.urlopen(request) as response:
    data=response.read().decode("utf-8")
print(data) #印出網頁的原始碼


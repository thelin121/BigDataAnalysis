from django.apps import AppConfig


class AppBmiAjaxConfig(AppConfig):
    name = 'app_bmi_ajax'

from django.shortcuts import render

def bmi_calculator(request):
    result = None
    category = None
    
    if request.method == 'POST':
        try:
            weight = float(request.POST.get('weight'))
            height = float(request.POST.get('height')) / 100  # Convert cm to m
            
            # Calculate BMI
            bmi = weight / (height * height)
            result = round(bmi, 2)
            
            # Determine BMI category
            if bmi < 18.5:
                category = '過輕'
            elif 18.5 <= bmi < 24:
                category = '正常'
            elif 24 <= bmi < 27:
                category = '過重'
            elif 27 <= bmi < 30:
                category = '輕度肥胖'
            elif 30 <= bmi < 35:
                category = '中度肥胖'
            else:
                category = '重度肥胖'
                
        except (ValueError, ZeroDivisionError):
            result = None
    
    context = {
        'result': result,
        'category': category
    }
    
    return render(request, 'bmi/calculator.html', context)

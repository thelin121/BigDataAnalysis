from django.apps import AppConfig


class AppUserKeywordConfig(AppConfig):
    name = 'app_user_keyword'

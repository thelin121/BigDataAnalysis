from django.apps import AppConfig


class AppUserKeywordConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_user_keyword'

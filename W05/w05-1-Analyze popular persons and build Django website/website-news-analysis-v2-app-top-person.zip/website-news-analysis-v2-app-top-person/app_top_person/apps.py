from django.apps import AppConfig


class AppTopPersonConfig(AppConfig):
    name = 'app_top_person'
